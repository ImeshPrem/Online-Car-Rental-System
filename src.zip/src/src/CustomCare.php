<?php
$myname = $_POST['name'];
$email = $_POST['email'];
$number = $_POST['phone'];
$report = $_POST['queries'];
$rtype = $_POST['solution'];
$ratings = $_POST['rate'];

$con =mysqli_connect('localhost','root','','userdb');

if(!$con){
	echo 'Error occured;';
}
else{
	$query = "INSERT INTO reports VALUES('$myname','$email','$number','$report','$rtype','$ratings')";
	
	if(mysqli_query($con,$query)) {
		function phpAlert($msg){
			echo '<script type="text/Javascript">alert("'.$msg.'")</script>';
		}
		phpAlert("SUCCESS! \n \n Your details updated successfuly");
	}
}

?>	
		
